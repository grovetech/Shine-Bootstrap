function type_select(elem) {

var chosenOption = elem.value;

if (chosenOption == '1' )
	{
			
	document.getElementById('piglatin').value = "Once upon a time there were three little pigs and the time came for them to leave home and seek their fortunes. Before they left, their mother told them  Whatever you do , do it the best that you can because that\'s the way to get along in the world.The first little pig built his house out of straw because it was the easiest thing to do.The second little pig built his house out of sticks. This was a little bit stronger than a straw house.The third little pig built his house out of bricks.One night the big bad wolf, who dearly loved to eat fat little piggies, came along and saw the first little pig in his house of straw. He said Let me in, Let me in, little pig or I will huff and I will puff and I will blow your house in! Not by the hair of my chinny chin chin, said the little pig. But of course the wolf did blow the house in and ate the first little pig. The wolf then came to the house of sticks. Let me in, Let me in little pig or I will huff and I will puff and I will blow your house in Not by the hair of my chinny chin chin, said the little pig. But the wolf blew that house in too, and ate the second little pig. The wolf then came to the house of bricks. Let me in, let me in cried the wolf Or I will huff and I will puff till I blow your house in Not by the hair of my chinny chin chin said the pigs. Well, the wolf huffed and puffed but he could not blow down that brick house. But the wolf was a sly old wolf and he climbed up on the roof to look for a way into the brick house. The little pig saw the wolf climb up on the roof and lit a roaring fire in the fireplace and placed on it a large kettle of water. When the wolf finally found the hole in the chimney he crawled down and KERSPLASH right into that kettle of water and that was the end of his troubles with the big bad wolf. The next day the little pig invited his mother over . She said You see it is just as I told you. The way to get along in the world is to do things as well as you can. Fortunately for that little pig, he learned that lesson. And he just lived happily ever after!"; 
    typing();
    }
    
    if (chosenOption == '2' )
	{
	
	document.getElementById('piglatin').value = "Mary has a little lamb, Its fleece was white as snow; And everywhere that Mary went,The lamb was sure to go.It followed her to school one day, That was against the rule; It made the children laugh and play, To see a lamb at school."; 
    typing();
	}

if (chosenOption == '3' )
	{
	
	document.getElementById('piglatin').value = "Peter Piper picked a peck of pickled peppers, A peck of pickled peppers Peter Piper picked. If Peter Piper picked a peck of pickled peppers, Where\'s the peck of pickled peppers that Peter Piper pick?"; 
    typing();

	}
    
    if (chosenOption == '4' )
	{
	
	document.getElementById('piglatin').value = "This old man, he played one, He played Nick Nack On my drum! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played two, He played Nick Nack On my shoe! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played three, He played Nick Nack On my knee! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played four, He played Nick Nack On my door! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played five, He played Nick Nack On my tie! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played six, He played Nick Nack On my sticks! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played seven, He played Nick Nack On my heaven! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played eight, He played Nick Nack On my gate! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played nine, He played Nick Nack On my pine! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.This old man, he played ten, He played Nick Nack On my pen! Nick Nack Paddy Whack!Give a dog a bone, This old man came rolling home.";   
    typing();                  

	}
    
    if (chosenOption == '5' )
	{
	
	document.getElementById('piglatin').value = "I\'d like to buy the world a home and furnish it with love, Grow apple trees and honey bees, and snow white turtle doves. I\'d like to teach the world to sing in perfect harmony, I\'d like to buy the world a Coke and keep it company. It\'s the real thing, Coke is what the world wants today."; 
    typing();

	}
    
    if (chosenOption == '6' )
	{
	
	document.getElementById('piglatin').value = "It\'s a shame that the only thing a man can do for eight hours a day is work. He can\'t eat for eight hours; he can\'t drink for eight hours; he can\'t make love for eight hours. The only thing a man can do for eight hours is work.";
    typing(); 

	}
    if (chosenOption == '7' )
	{
	
	document.getElementById('piglatin').value = "Here\'s to the crazy ones. The misfits. The rebels. The troublemakers. The round pegs in the square holes. The ones who see things differently. They\'re not fond of rules, And they have no respect for the status quo. You can praise them, disagree with them, quote them,disbelieve them, glorify or vilify them. About the only thing that you can\'t do is ignore them. Because they change things. They invent. They imagine. They heal. They explore. They create.  They inspire. They push the human race forward. Maybe they have to be crazy.  How else can you stare at an empty canvas and see a work of art? Or sit in silence and hear a song thats never been written? Or gaze at a red planet and see a laboratory on wheels? We make tools for these kinds of people.  While some may see them as the crazy ones, we see genius.  Because the ones who are crazy enough to think that they can change the world, are the ones who do. "; 
    typing();
	}
    
    if (chosenOption == '8' )
	{
	document.getElementById('piglatin').value = "When a man sits with a pretty girl for an hour, it seems like a minute. But let him sit on a hot stove for a minute--and it's longer than any hour. thats true relativity."; 
    typing();
    }
    
}