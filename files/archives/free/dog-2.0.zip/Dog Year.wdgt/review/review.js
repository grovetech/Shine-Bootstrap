var updateURL = "http://www.macupdate.com/app/mac/26581/dog-year-calculator";	// replace with the website URL to show

// Show website code
function ratemacupdate() {

widget.openURL(updateURL);

// Values you provide
var preferenceKeystop = "stop";		// replace with the key for a preference
var preferenceValuestop = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuestop, preferenceKeystop);

// Values you provide
var preferenceKeyreviewed = "reviewed";		// replace with the key for a preference
var preferenceValuereviewed = true;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuereviewed, preferenceKeyreviewed);

// Values you provide
var itemToFadeOut = document.getElementById("dazzle-alertBox2");	// replace with name of element to fade

// Fading code
var fadeHandler = function(a, c, s, f){ itemToFadeOut.style.opacity = c; };
new AppleAnimator(500, 13, 1.0, 0.0, fadeHandler).start();


}

var updateURL2 = "http://www.dashboardwidgets.com/showcase/details.php?wid=2237";	// replace with the website URL to show

// Show website code
function ratemacupdate2() {

widget.openURL(updateURL2);

// Values you provide
var preferenceKeystop = "stop";		// replace with the key for a preference
var preferenceValuestop = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuestop, preferenceKeystop);


// Values you provide
var preferenceKeyreviewed = "reviewed";		// replace with the key for a preference
var preferenceValuereviewed = true;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuereviewed, preferenceKeyreviewed);

// Values you provide
var itemToFadeOut = document.getElementById("dazzle-alertBox2");	// replace with name of element to fade

// Fading code
var fadeHandler = function(a, c, s, f){ itemToFadeOut.style.opacity = c; };
new AppleAnimator(500, 13, 1.0, 0.0, fadeHandler).start();

}


var updateURL3 = "http://osx.iusethis.com/app/dogagecalculator";	// replace with the website URL to show

// Show website code
function ratemacupdate3() {

widget.openURL(updateURL3);


// Values you provide
var preferenceKeystop = "stop";		// replace with the key for a preference
var preferenceValuestop = true;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuestop, preferenceKeystop);

// Values you provide
var itemToFadeOut = document.getElementById("dazzle-alertBox3");	// replace with name of element to fade

// Fading code
var fadeHandler = function(a, c, s, f){ itemToFadeOut.style.opacity = c; };
new AppleAnimator(500, 13, 1.0, 0.0, fadeHandler).start();

}



function hidereview() {

document.getElementById('dazzle-alertBox2').style.display = 'none';

// Values you provide
var preferenceKeyreviewed = "reviewed";		// replace with the key for a preference
var preferenceValuereviewed = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuereviewed, preferenceKeyreviewed);

// Values you provide
var preferenceKeystop = "stop";		// replace with the key for a preference
var preferenceValuestop = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuestop, preferenceKeystop);

}


function hidereview2() {

document.getElementById('dazzle-alertBox3').style.display = 'none';

// Values you provide
var preferenceKeyreviewed = "reviewed";		// replace with the key for a preference
var preferenceValuereviewed = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuereviewed, preferenceKeyreviewed);

// Values you provide
var preferenceKeystop = "stop";		// replace with the key for a preference
var preferenceValuestop = false;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuestop, preferenceKeystop);

}

function setdate() {

// Values you provide
var preferenceForKey = "installed";	// replace with the key for a preference

// Preference code
preferenceForKey = widget.preferenceForKey(preferenceForKey);

if (preferenceForKey == true) {

alert ("Your Fine");

} else {

// Values you provide
var preferenceKeydate = "installdate";		// replace with the key for a preference
var preferenceValuedate = Date();	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValuedate, preferenceKeydate);

// Values you provide
var preferenceKeyinstall = "installed";		// replace with the key for a preference
var preferenceValueinstall = true;	// replace with a preference to save

// Preference code
widget.setPreferenceForKey(preferenceValueinstall, preferenceKeyinstall);

}

}

function calculateTime(){

// Values you provide
var preferenceForKeydate2 = "installdate";	// replace with the key for a preference

// Preference code
preferenceForKeydate2 = widget.preferenceForKey(preferenceForKeydate2);

// Values you provide
var preferenceForKeyreviewed2 = "reviewed";	// replace with the key for a preference

// Preference code
preferenceForKeyreviewed2 = widget.preferenceForKey(preferenceForKeyreviewed2);

// Values you provide
var preferenceForKeystop2 = "stop";	// replace with the key for a preference

// Preference code
preferenceForKeystop2 = widget.preferenceForKey(preferenceForKeystop2);


var prevTime = new Date(preferenceForKeydate2);  // Jan 1, 2011
var thisTime = new Date();              // now
var diff = thisTime.getTime() - prevTime.getTime();   // now - jan 1

var actualtime = diff / (1000*60*60*24); // positive number of days
alert(actualtime);

if (preferenceForKeyreviewed2 == true) {

document.getElementById('dazzle-alertBox2').style.display = 'none';

} else if ((preferenceForKeystop2 == false) && (preferenceForKeyreviewed2 == true) && (actualtime > 15)) { 

document.getElementById('dazzle-alertBox3').style.display = 'block';

} else if ((preferenceForKeystop2 == true) && (preferenceForKeyreviewed2 == true)) {

document.getElementById('dazzle-alertBox3').style.display = 'none'; 

} else {

if ((actualtime > 2) && (actualtime <= 3) || (actualtime > 8) && (actualtime <= 10) || (actualtime > 15) && (actualtime <=22) || (actualtime > 26) && (actualtime <= 30)) {

document.getElementById('dazzle-alertBox2').style.display = 'block';

} else  {

document.getElementById('dazzle-alertBox2').style.display = 'none';

}

}

}