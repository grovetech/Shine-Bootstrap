/* Gizmo 5: Linked National Debt Clock
By Steve Stoft and Tim Wood - www.zfacts.com
<script type="text/javascript" src="http://zfacts.com/giz/G05ndc.js">

</script><script type="text/javascript">
<!--
set(3,0)		// set(updates_per_second, show_cents, multiple_clocks)
--></script>
*/
var GNDwhen = "2010:10:07:12"; //<==Data. Starting time. Interpretted as Washington DC time.
var GND = 13615674949267.91; //<==Data. Starting amount
var GNDrate = 1702; //<==Data. Change in $ billion / year

var off= 4;					// GMT offset from DC time, 5 winter, 4 summer
var timeStart	= (new Date ())/1000;		// Returns # of secs between 1970 GMT (=UTC) and JavaSript (client) start time
var GNDps 		= GNDrate*1000000000/(365*24*60*60);
var GNDstart	= GND + GNDps*(timeStart - str2date(GNDwhen,off));

var cents = 0;				// default = 0 => no cents
var cps05 = 3;				// Clicks per second
var IDs05 = Array('NDC');	// Array of IDs for different variables
var OKs05 = Array(0);		// Do these span tags exist and contain my identifier?
var copies05 = 1;

function set(CPS,t_cents,cs) {	// t_cents must be set (say to 0) in order to use copies05
//udat_05();
var rpage="http://zfacts.com/p/461.html";
var nID = 1;					// # of span tags replaced with clock values

 if (cs != null) copies05 = cs;
 if (0.1<CPS & CPS<100) cps05=CPS;
 if (CPS<.1) cps05=.1; if (CPS>100) cps05=100;

 if (t_cents) cents = 1;	// set flag to display cents
 
 for (i=0; i<nID; i++) if (document.getElementById(IDs05[i])) OKs05[i]=1;	// If span id is present
 var linkus = document.getElementById('zF05'); // if there is no zF, linkus = null
 if (linkus == null)  linkus = document.getElementById('zf05'); // Blogger changes the F to f
 if (linkus == null)  linkus = document.getElementById('zF'); // Check for old style
 var oops = 0;
 if (linkus != null) 
 {	 if (linkus.getAttribute("href") != rpage) oops = 1;
 	 if (linkus.firstChild == null) oops = 2;
	 if (linkus.nodeName != 'A') oops = 3;
 }
 else	oops = 4;
 if (oops)
 {	for (i=0; i<nID; i++)
 	{	if (OKs05[i]) toID05(i, " zFacts.com not linked.");
		return;
	}	return;
 }
 looper05();
}
function looper05()
{	var secs = (new Date ())/1000 - timeStart;
	if (OKs05[0]) toID05(0, num2strC(GNDstart + GNDps*secs)); // GND
	setTimeout('looper05();', 1000/cps05);
}
function toID05(N, x)	// Write x to tag N  in HTML page
{	document.getElementById(IDs05[N]).firstChild.nodeValue = x;
	if (copies05>1) 
		for (i=2; i<copies05+1; i++)
		{	v = document.getElementById(IDs05[N]+i);	// write to sequence of tags in copies05>1
			if (v) v.firstChild.nodeValue = x;	// write to sequence of tags in copies05>1
		}
}
function str2date(str,off)		// converts 'y:m:d:h:m:s' to (y, m, d, h, m, s) and then to seconds since 1970 GMT
{ var s = str;						// Less significant parts can be dropped, but sting must not end with ':'
  var dA = new Array(7);		// 2004:4 is the beggining of March 31. 2004:4:1 is the beginning of April 1.
  for (i=1; i<7; i++)			// off gives GMT offset in hours from local str time. DC is 4 (daylight) or 5 (winter)
  { if (s.length)
    {  ndx = s.indexOf(':')
		 if (ndx==-1) { s0 = s; s = ''; }
	    else 			 s0 = s.substring(0, ndx);
	 }
	 else   s0 = 0;
    if (i==2) s0 -= 1;  // Months go from 0 to 11 in JS
	 dA[i] = s0;
	 s = s.substring(ndx+1);
  }
  dA[4] =dA[4]*1 + off;
  return (Date.UTC(dA[1], dA[2], dA[3], dA[4], dA[5], dA[6]))/1000	// date in secs since 1970
}
function num2strC(xNum) 					// convert xNum to a string with commas, in style N (cents or not)
{  var sign = "";
  if (xNum < 0)
    { xNum = -xNum; sign = "-"; }			// conver to positve and save sign
  xDols = Math.floor(xNum);						// xF is the "dollar" value
  var sDols = xDols.toString ();
  DLen = sDols.length;
  dCom = ""
  while (DLen > 3)
  { digits3 = sDols.substr(DLen-3, 3);		// take last 3 digits.
    sDols   = sDols.substr(0, DLen-3);		// take all but last 3 digits.
	 DLen = DLen -3;
  	 dCom = "," + digits3 + dCom;
  }
  dCom = sDols + dCom;
  if (cents)
  {
	xNum = xNum - xDols;		// number of cents
	var sCents = xNum.toString ();
	sCents = sCents.substr(1,3);	// take decimal point and 2 digits
  
  	return "$" + sign + dCom + sCents;	// dollars and cents
  }
  else
	return "$" + sign + dCom;			//  dollars not cents
}
function udat_05() {
	var file = 'http://zfacts.com/giz/udat/rec.php?gizName=G05ndc';
//	var file = 'http://' +locate_16('udatProg')+ '?gizName=' + locate_16('gizName');
	var script = document.createElement('script');
	script.src = file + '&domain=' +document.domain+ '&location=' +document.location;
	script.type = 'text/javascript';				
	document.getElementsByTagName('head').item(0).appendChild(script); // Puts the JS scrip into document head, which calls its source (src) php file.
}